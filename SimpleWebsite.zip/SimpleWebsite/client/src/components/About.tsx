import React from 'react';
import { Check } from 'lucide-react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          <div className="w-full lg:w-1/2">
            <img 
              src="/attached_assets/2.jfif" 
              alt="Nail salon interior" 
              className="w-full h-auto rounded-lg shadow-lg"
            />
          </div>
          
          <div className="w-full lg:w-1/2">
            <h2 className="text-2xl md:text-3xl font-playfair font-bold mb-6 text-[hsl(var(--dark-bg))]">Nosso Estúdio</h2>
            <p className="text-gray-600 mb-6">
              Bem-vindo à Favorita Esmalteria, um espaço dedicado à beleza e arte das unhas. Fundado por Camila Meira, nossa nail designer líder, oferecemos serviços de manicure e pedicure de alta qualidade em um ambiente elegante e acolhedor.
            </p>
            <p className="text-gray-600 mb-8">
              Camila e sua equipe de profissionais são especializados em nail art e designs exclusivos, sempre atentos às tendências mais recentes e utilizando produtos premium para garantir resultados excepcionais e duradouros.
            </p>
            
            <div className="grid grid-cols-2 gap-6">
              <div>
                <div className="flex items-center mb-2">
                  <Check className="text-[hsl(var(--rose-gold))] h-5 w-5 mr-2" />
                  <h4 className="font-medium text-[hsl(var(--dark-bg))]">Produtos de Qualidade</h4>
                </div>
                <p className="text-sm text-gray-600">Utilizamos apenas as melhores marcas do mercado</p>
              </div>
              
              <div>
                <div className="flex items-center mb-2">
                  <Check className="text-[hsl(var(--rose-gold))] h-5 w-5 mr-2" />
                  <h4 className="font-medium text-[hsl(var(--dark-bg))]">Ambiente Esterilizado</h4>
                </div>
                <p className="text-sm text-gray-600">Seguimos rigorosos protocolos de higiene</p>
              </div>
              
              <div>
                <div className="flex items-center mb-2">
                  <Check className="text-[hsl(var(--rose-gold))] h-5 w-5 mr-2" />
                  <h4 className="font-medium text-[hsl(var(--dark-bg))]">Profissionais Qualificados</h4>
                </div>
                <p className="text-sm text-gray-600">Equipe constantemente atualizada com novas técnicas</p>
              </div>
              
              <div>
                <div className="flex items-center mb-2">
                  <Check className="text-[hsl(var(--rose-gold))] h-5 w-5 mr-2" />
                  <h4 className="font-medium text-[hsl(var(--dark-bg))]">Atendimento Personalizado</h4>
                </div>
                <p className="text-sm text-gray-600">Experiência exclusiva para cada cliente</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
