import React from 'react';
import { FaWhatsapp } from 'react-icons/fa';

const CTA: React.FC = () => {
  return (
    <section className="py-16 bg-[hsl(var(--rose-gold))]">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-2xl md:text-3xl font-playfair font-bold mb-6 text-white">
          Agende seu Horário
        </h2>
        <p className="text-white mb-8 max-w-2xl mx-auto">
          Transforme suas unhas em verdadeiras obras de arte. 
          Entre em contato agora mesmo e garanta um horário com nossos especialistas.
        </p>
        
        <a 
          href="https://api.whatsapp.com/send/?phone=11915180888&text&type=phone_number&app_absent=0" 
          target="_blank" 
          rel="noopener noreferrer" 
          className="contact-btn inline-flex items-center gap-2 bg-white text-[hsl(var(--rose-gold))] px-8 py-3 rounded-md font-medium"
        >
          <FaWhatsapp className="h-5 w-5" />
          Agendar pelo WhatsApp
        </a>
      </div>
    </section>
  );
};

export default CTA;
