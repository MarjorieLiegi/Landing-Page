import React from 'react';
import { MapPin, Clock, Phone, Mail, Instagram, Facebook } from 'lucide-react';
import { FaWhatsapp } from 'react-icons/fa';

const Contact: React.FC = () => {
  const contactInfo = [
    {
      icon: <MapPin className="h-5 w-5" />,
      title: 'Endereço',
      details: ['R. Avanhandava, 20 - Vila Gilda', 'Santo André - SP, 09190-370']
    },
    {
      icon: <Clock className="h-5 w-5" />,
      title: 'Horário de Funcionamento',
      details: ['Segunda a Sábado: 9h às 20h', 'Domingo: Fechado']
    },
    {
      icon: <Phone className="h-5 w-5" />,
      title: 'Telefone',
      details: ['+55 11 91518-0888']
    },
    {
      icon: <Mail className="h-5 w-5" />,
      title: 'Email',
      details: ['contato@favoritaesmalteria.com.br']
    }
  ];

  const socialMedia = [
    {
      icon: <Instagram className="h-5 w-5" />,
      url: 'https://www.instagram.com/esmalteriafavoritanail/?igsh=bWlydWM2bDR2dmJl',
      label: 'Instagram'
    },
    {
      icon: <FaWhatsapp className="h-5 w-5" />,
      url: 'https://api.whatsapp.com/send/?phone=11915180888&text&type=phone_number&app_absent=0',
      label: 'WhatsApp'
    }
  ];

  return (
    <section id="contact" className="py-20">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div>
            <h2 className="text-2xl md:text-3xl font-playfair font-bold mb-6 text-[hsl(var(--dark-bg))]">
              Entre em Contato
            </h2>
            <p className="text-gray-600 mb-8">
              Estamos prontos para atender você e criar designs incríveis para suas unhas. 
              Agende seu horário ou tire suas dúvidas através dos nossos canais de contato.
            </p>
            
            <div className="space-y-6">
              {contactInfo.map((info, index) => (
                <div key={index} className="flex items-start">
                  <div className="flex-shrink-0 mt-1">
                    <div className="flex items-center justify-center h-10 w-10 rounded-full bg-[hsl(var(--rose-gold)_/_0.2)] text-[hsl(var(--rose-gold))]">
                      {info.icon}
                    </div>
                  </div>
                  <div className="ml-4">
                    <h4 className="text-lg font-medium text-[hsl(var(--dark-bg))] mb-1">{info.title}</h4>
                    {info.details.map((detail, i) => (
                      <p key={i} className="text-gray-600">{detail}</p>
                    ))}
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-10">
              <h4 className="text-lg font-medium text-[hsl(var(--dark-bg))] mb-4">Nossas Redes Sociais</h4>
              <div className="flex space-x-4">
                {socialMedia.map((social, index) => (
                  <a 
                    key={index}
                    href={social.url} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="social-icon flex items-center justify-center h-12 w-12 rounded-full bg-[hsl(var(--rose-gold))] text-white"
                    aria-label={social.label}
                  >
                    {social.icon}
                  </a>
                ))}
              </div>
            </div>
          </div>
          
          <div>
            <div className="bg-white shadow-lg rounded-lg overflow-hidden h-full">
              <div className="h-[300px] sm:h-[400px] md:h-[500px] lg:h-full w-full">
                <iframe 
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3655.1064080569474!2d-46.5353675!3d-23.6474805!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce42735b809ad1%3A0x9215ec45809004f7!2sR.%20Avanhandava%2C%2020%20-%20Vila%20Gilda%2C%20Santo%20Andr%C3%A9%20-%20SP%2C%2009190-370!5e0!3m2!1spt-BR!2sbr!4v1712785021752!5m2!1spt-BR!2sbr" 
                  width="100%" 
                  height="100%" 
                  style={{ border: 0 }} 
                  allowFullScreen 
                  loading="lazy" 
                  referrerPolicy="no-referrer-when-downgrade"
                  title="Localização da Favorita Esmalteria"
                ></iframe>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
