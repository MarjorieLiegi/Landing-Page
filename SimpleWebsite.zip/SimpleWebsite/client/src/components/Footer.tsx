import React from 'react';
import { Instagram, Facebook } from 'lucide-react';
import { FaWhatsapp } from 'react-icons/fa';

const Footer: React.FC = () => {
  const navigation = [
    { name: 'Início', href: '#home' },
    { name: 'Sobre', href: '#about' },
    { name: 'Galeria', href: '#gallery' },
    { name: 'Serviços', href: '#services' },
    { name: 'Contato', href: '#contact' },
  ];

  const socialMedia = [
    { icon: <Instagram className="h-4 w-4" />, href: 'https://www.instagram.com/esmalteriafavoritanail/?igsh=bWlydWM2bDR2dmJl', label: 'Instagram' },
    { icon: <FaWhatsapp className="h-4 w-4" />, href: 'https://api.whatsapp.com/send/?phone=11915180888&text&type=phone_number&app_absent=0', label: 'WhatsApp' },
  ];

  return (
    <footer className="py-10 bg-[hsl(var(--dark-bg))] text-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-6 md:mb-0">
            <h3 className="text-xl font-playfair font-semibold">
              <span style={{ color: 'hsl(var(--rose-gold-light))' }}>Favorita</span>
              <span className="text-white"> Esmalteria</span>
            </h3>
            <p className="text-gray-400 mt-2">Beleza e arte para suas unhas por Camila Meira</p>
          </div>
          
          <div className="flex flex-col md:flex-row items-center space-y-4 md:space-y-0 md:space-x-8">
            {navigation.map((item) => (
              <a 
                key={item.name}
                href={item.href} 
                className="text-gray-300 hover:text-[hsl(var(--rose-gold-light))] transition-colors"
              >
                {item.name}
              </a>
            ))}
          </div>
        </div>
        
        <hr className="border-gray-700 my-8" />
        
        <div className="flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm mb-4 md:mb-0">
            © {new Date().getFullYear()} Favorita Esmalteria. Todos os direitos reservados.
          </p>
          
          <div className="flex space-x-4">
            {socialMedia.map((social, index) => (
              <a 
                key={index}
                href={social.href} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-gray-400 hover:text-[hsl(var(--rose-gold-light))] transition-colors"
                aria-label={social.label}
              >
                {social.icon}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
