import React from 'react';
import { Instagram } from 'lucide-react';

const Gallery: React.FC = () => {
  const galleryImages = [
    { src: '/attached_assets/3.jfif', alt: 'Nail art design' },
    { src: '/attached_assets/4.jfif', alt: 'Nail art design' },
    { src: '/attached_assets/5.jfif', alt: 'Nail art design' },
    { src: '/attached_assets/6.jfif', alt: 'Nail art design' },
    { src: '/attached_assets/7.jfif', alt: 'Nail art design' },
    { src: '/attached_assets/8.jfif', alt: 'Nail art design' },
  ];

  return (
    <section id="gallery" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-2xl md:text-3xl font-playfair font-bold mb-4 text-[hsl(var(--dark-bg))]">Nossa Galeria</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Confira alguns dos nossos trabalhos e inspire-se para sua próxima visita. 
            Criamos designs exclusivos que combinam com seu estilo e personalidade.
          </p>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {galleryImages.map((image, index) => (
            <div key={index} className="gallery-item rounded-lg overflow-hidden shadow-md">
              <img 
                src={image.src} 
                alt={image.alt} 
                className="w-full h-80 object-cover"
              />
            </div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <a 
            href="https://www.instagram.com/esmalteriafavoritanail/?igsh=bWlydWM2bDR2dmJl" 
            target="_blank" 
            rel="noopener noreferrer" 
            className="contact-btn inline-flex items-center gap-2 bg-[hsl(var(--rose-gold))] text-white px-8 py-3 rounded-md font-medium"
          >
            <Instagram className="h-5 w-5" />
            Ver mais no Instagram
          </a>
        </div>
      </div>
    </section>
  );
};

export default Gallery;
