import React from 'react';
import { useMobileMenu } from '@/hooks/use-mobile-menu';
import { Menu, X } from 'lucide-react';

const Header: React.FC = () => {
  const { isMenuOpen, toggleMenu, closeMenu } = useMobileMenu();

  return (
    <header className="fixed top-0 left-0 right-0 bg-white bg-opacity-95 z-50 shadow-sm">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center">
          <img 
            src="/attached_assets/logo.jfif" 
            alt="Favorita Esmalteria Logo" 
            className="h-12 w-auto mr-3"
          />
          <h1 className="text-xl md:text-2xl font-playfair font-semibold" style={{ color: 'hsl(var(--rose-gold))' }}>
            Favorita <span className="text-darkBg-DEFAULT" style={{ color: 'hsl(var(--dark-bg))' }}>Esmalteria</span>
          </h1>
        </div>
        
        {/* Mobile menu button */}
        <button 
          type="button" 
          onClick={toggleMenu}
          className="md:hidden focus:outline-none"
          aria-label={isMenuOpen ? "Fechar menu" : "Abrir menu"}
        >
          {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
        
        {/* Desktop Navigation */}
        <nav className="hidden md:flex space-x-8">
          <a href="#home" className="nav-link text-darkBg-DEFAULT hover:text-roseGold transition-colors">Início</a>
          <a href="#about" className="nav-link text-darkBg-DEFAULT hover:text-roseGold transition-colors">Sobre</a>
          <a href="#gallery" className="nav-link text-darkBg-DEFAULT hover:text-roseGold transition-colors">Galeria</a>
          <a href="#services" className="nav-link text-darkBg-DEFAULT hover:text-roseGold transition-colors">Serviços</a>
          <a href="#contact" className="nav-link text-darkBg-DEFAULT hover:text-roseGold transition-colors">Contato</a>
        </nav>
      </div>
      
      {/* Mobile Navigation */}
      <nav className={`px-4 py-2 pb-4 bg-white md:hidden ${isMenuOpen ? 'block' : 'hidden'}`}>
        <div className="flex flex-col space-y-3">
          <a href="#home" onClick={closeMenu} className="text-darkBg-DEFAULT py-2 hover:text-roseGold transition-colors">Início</a>
          <a href="#about" onClick={closeMenu} className="text-darkBg-DEFAULT py-2 hover:text-roseGold transition-colors">Sobre</a>
          <a href="#gallery" onClick={closeMenu} className="text-darkBg-DEFAULT py-2 hover:text-roseGold transition-colors">Galeria</a>
          <a href="#services" onClick={closeMenu} className="text-darkBg-DEFAULT py-2 hover:text-roseGold transition-colors">Serviços</a>
          <a href="#contact" onClick={closeMenu} className="text-darkBg-DEFAULT py-2 hover:text-roseGold transition-colors">Contato</a>
        </div>
      </nav>
    </header>
  );
};

export default Header;
