import React from 'react';

const Hero: React.FC = () => {
  return (
    <section id="home" className="relative h-screen pt-16 overflow-hidden">
      <div className="absolute inset-0 z-0">
        <div 
          className="w-full h-full bg-center bg-cover"
          style={{ 
            backgroundImage: `url('/attached_assets/8.jfif')`,
            backgroundPosition: 'center',
            backgroundSize: 'cover'
          }}
        />
        <div className="hero-overlay absolute inset-0"></div>
      </div>
      
      <div className="container mx-auto px-4 h-full relative z-10 flex flex-col justify-center items-center text-center">
        <h2 className="text-3xl md:text-5xl lg:text-6xl font-playfair font-bold text-white mb-4 tracking-wide">
          Favorita Esmalteria
        </h2>
        <p className="text-lg md:text-xl text-gray-100 max-w-2xl mb-8">
          Transforme suas unhas em verdadeiras obras de arte com designs exclusivos e atendimento personalizado
        </p>
        <div className="flex flex-col sm:flex-row gap-4">
          <a 
            href="#gallery" 
            className="contact-btn bg-[hsl(var(--rose-gold))] text-white px-8 py-3 rounded-md font-medium"
          >
            Ver Galeria
          </a>
          <a 
            href="https://api.whatsapp.com/send/?phone=11915180888&text&type=phone_number&app_absent=0"
            target="_blank"
            rel="noopener noreferrer" 
            className="contact-btn bg-transparent border-2 border-white text-white px-8 py-3 rounded-md font-medium hover:bg-white hover:text-[hsl(var(--dark-bg))] transition-colors"
          >
            Agendar Horário
          </a>
        </div>
      </div>
    </section>
  );
};

export default Hero;
