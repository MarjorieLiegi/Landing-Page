import React from 'react';
import { Paintbrush, Gem, Wand2, Bath, Droplet, Sparkles } from 'lucide-react';

const Services: React.FC = () => {
  const services = [
    {
      icon: <Paintbrush className="h-6 w-6" />,
      title: 'Manicure Tradicional',
      description: 'Cuidados completos para suas unhas, incluindo corte, lixamento, cutículas e esmaltação.'
    },
    {
      icon: <Gem className="h-6 w-6" />,
      title: 'Nail Art Personalizada',
      description: 'Designs exclusivos e personalizados com técnicas avançadas e materiais premium.'
    },
    {
      icon: <Wand2 className="h-6 w-6" />,
      title: 'Alongamento de Fibra de Vidro',
      description: 'Alongamento das unhas com fibra de vidro para maior resistência e acabamento natural.'
    },
    {
      icon: <Bath className="h-6 w-6" />,
      title: 'Pedicure Completa',
      description: 'Tratamento completo para os pés, incluindo esfoliação, hidratação e esmaltação.'
    },
    {
      icon: <Droplet className="h-6 w-6" />,
      title: 'Esmaltação em Gel',
      description: 'Esmaltação duradoura com secagem imediata e brilho intenso.'
    },
    {
      icon: <Sparkles className="h-6 w-6" />,
      title: 'Plástica dos Pés',
      description: 'Tratamento completo para rejuvenescimento e embelezamento dos pés, com esfoliação, hidratação intensa e cuidados especiais.'
    }
  ];

  return (
    <section id="services" className="py-20 bg-[hsl(var(--cream)_/_0.2)]">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-2xl md:text-3xl font-playfair font-bold mb-4 text-[hsl(var(--dark-bg))]">
            Nossos Serviços
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Oferecemos uma variedade de serviços para cuidar da beleza das suas unhas com qualidade e profissionalismo.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div 
              key={index} 
              className="bg-white p-8 rounded-lg shadow-md transition-transform duration-300 hover:-translate-y-2"
            >
              <div className="flex justify-center items-center h-16 w-16 rounded-full bg-[hsl(var(--rose-gold)_/_0.2)] text-[hsl(var(--rose-gold))] mb-6 mx-auto">
                {service.icon}
              </div>
              <h3 className="text-xl font-playfair font-semibold text-center mb-4">{service.title}</h3>
              <p className="text-gray-600 text-center">{service.description}</p>
              <div className="text-center mt-6">
                <a 
                  href="https://api.whatsapp.com/send/?phone=11915180888&text&type=phone_number&app_absent=0"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[hsl(var(--rose-gold))] hover:text-[hsl(var(--rose-gold-dark))] font-medium transition-colors"
                >
                  Consultar disponibilidade
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
