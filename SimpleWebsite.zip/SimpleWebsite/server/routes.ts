import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import path from "path";

export async function registerRoutes(app: Express): Promise<Server> {
  // Static file handler for attached assets
  app.get('/attached_assets/:filename', (req, res) => {
    const { filename } = req.params;
    const filePath = path.resolve(process.cwd(), 'attached_assets', filename);
    res.sendFile(filePath);
  });

  // API endpoint for contact form (as an example)
  app.post('/api/contact', (req, res) => {
    const { name, email, message } = req.body;
    
    // In a real app, you would save this to a database or send an email
    // Here we're just sending a success response
    res.json({
      success: true,
      message: "Mensagem recebida com sucesso!"
    });
  });

  const httpServer = createServer(app);

  return httpServer;
}
